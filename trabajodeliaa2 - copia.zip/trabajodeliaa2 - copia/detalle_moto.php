<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Detalles de Moto Yamaha</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <?php 
    include 'database/config.php';
    include 'includes/header.php'; 
    
    $id_moto = $_GET['id'] ?? null;
    
    if ($id_moto) {
        $consulta = "SELECT * FROM motos WHERE id = $id_moto";
        $resultado = $conexion->query($consulta);
        $moto = $resultado->fetch_assoc();
    }
    ?>

    <div class="container mt-5">
        <?php if ($moto): ?>
        <div class="row">
            <div class="col-md-6">
                <img src="img/<?php echo $moto['imagen']; ?>" class="img-fluid" alt="<?php echo $moto['modelo']; ?>">
            </div>
            <div class="col-md-6">
                <h1><?php echo $moto['modelo']; ?></h1>
                <p><?php echo $moto['descripcion']; ?></p>
                <ul class="list-group">
                    <li class="list-group-item"><strong>Categoría:</strong> <?php echo $moto['categoria']; ?></li>
                    <li class="list-group-item"><strong>Cilindrada:</strong> <?php echo $moto['cilindrada']; ?> cc</li>
                    <li class="list-group-item"><strong>Potencia:</strong> <?php echo $moto['potencia']; ?></li>
                    <li class="list-group-item"><strong>Precio:</strong> €<?php echo number_format($moto['precio'], 2); ?></li>
                </ul>
                <a href="contacto.php?modelo=<?php echo urlencode($moto['modelo']); ?>" class="btn btn-success mt-3">Solicitar Información</a>
            </div>
        </div>
        <?php else: ?>
        <div class="alert alert-danger">Moto no encontrada</div>
        <?php endif; ?>
    </div>

    <?php include 'includes/footer.php'; ?>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
