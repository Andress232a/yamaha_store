from app import create_app
from app.models.models import db, Pedido

app = create_app()

with app.app_context():
    # Crear la columna estado si no existe
    try:
        Pedido.query.first().estado
    except:
        # Ejecutar el comando SQL para agregar la columna
        db.engine.execute("""
            ALTER TABLE pedido
            ADD COLUMN estado VARCHAR(20) DEFAULT 'Pendiente';
        """)
        
        # Actualizar los registros existentes
        db.engine.execute("""
            UPDATE pedido
            SET estado = 'Pendiente'
            WHERE estado IS NULL;
        """)
        
        print("Columna estado agregada exitosamente")
    
    # Verificar que la columna existe
    try:
        Pedido.query.first().estado
        print("La columna estado está presente en la tabla")
    except Exception as e:
        print(f"Error: {str(e)}")
