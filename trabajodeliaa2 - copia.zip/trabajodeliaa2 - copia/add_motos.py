from app.models.models import db, Moto
from app import create_app

app = create_app()

motos_por_categoria = {
    'Deportiva': [
        {'modelo': 'Yamaha YZF-R1', 'precio': 22500, 'descripcion': 'Moto deportiva de alto rendimiento', 'imagen': 'r1.jpg', 'cilindrada': 998, 'potencia': '200 CV', 'stock': 5, 'año': 2023, 'color': 'Azul', 'tipo_motor': 'Inline-4', 'peso': 201},
        {'modelo': 'Yamaha YZF-R6', 'precio': 15000, 'descripcion': 'Moto deportiva de media cilindrada', 'imagen': 'r6.jpg', 'cilindrada': 600, 'potencia': '120 CV', 'stock': 7, 'año': 2022, 'color': 'Rojo', 'tipo_motor': 'Inline-4', 'peso': 190},
        {'modelo': 'Yamaha R7', 'precio': 9500, 'descripcion': 'Moto deportiva accesible', 'imagen': 'r7.jpg', 'cilindrada': 689, 'potencia': '72 CV', 'stock': 10, 'año': 2023, 'color': 'Gris', 'tipo_motor': 'Parallel-twin', 'peso': 188},
        {'modelo': 'Yamaha R3', 'precio': 5500, 'descripcion': 'Moto deportiva para principiantes', 'imagen': 'r3.jpg', 'cilindrada': 321, 'potencia': '42 CV', 'stock': 15, 'año': 2023, 'color': 'Negro', 'tipo_motor': 'Inline-2', 'peso': 170},
        {'modelo': 'Yamaha R125', 'precio': 4800, 'descripcion': 'Deportiva para jóvenes pilotos', 'imagen': 'r125.jpg', 'cilindrada': 125, 'potencia': '15 CV', 'stock': 20, 'año': 2023, 'color': 'Blanco', 'tipo_motor': 'Monocilíndrico', 'peso': 140}
    ],
    'Naked': [
        {'modelo': 'Yamaha MT-10', 'precio': 18500, 'descripcion': 'Naked de alto rendimiento', 'imagen': 'mt10.jpg', 'cilindrada': 998, 'potencia': '190 CV', 'stock': 6, 'año': 2023, 'color': 'Gris', 'tipo_motor': 'Inline-4', 'peso': 210},
        {'modelo': 'Yamaha MT-09', 'precio': 10500, 'descripcion': 'Naked versátil y divertida', 'imagen': 'mt09.jpg', 'cilindrada': 890, 'potencia': '119 CV', 'stock': 12, 'año': 2022, 'color': 'Azul', 'tipo_motor': 'Inline-3', 'peso': 190},
        {'modelo': 'Yamaha MT-07', 'precio': 7500, 'descripcion': 'Naked ligera y ágil', 'imagen': 'mt07.jpg', 'cilindrada': 689, 'potencia': '74 CV', 'stock': 15, 'año': 2023, 'color': 'Blanco', 'tipo_motor': 'Parallel-twin', 'peso': 182},
        {'modelo': 'Yamaha MT-03', 'precio': 5200, 'descripcion': 'Naked para nuevos conductores', 'imagen': 'mt03.jpg', 'cilindrada': 321, 'potencia': '42 CV', 'stock': 18, 'año': 2023, 'color': 'Negro', 'tipo_motor': 'Monocilíndrico', 'peso': 168},
        {'modelo': 'Yamaha MT-125', 'precio': 4500, 'descripcion': 'Naked para jóvenes', 'imagen': 'mt125.jpg', 'cilindrada': 125, 'potencia': '15 CV', 'stock': 22, 'año': 2023, 'color': 'Rojo', 'tipo_motor': 'Monocilíndrico', 'peso': 140}
    ],
    'Scooter': [
        {'modelo': 'Yamaha TMAX', 'precio': 15000, 'descripcion': 'Scooter de alta gama', 'imagen': 'tmax.jpg', 'cilindrada': 560, 'potencia': '55 CV', 'stock': 8, 'año': 2023, 'color': 'Gris', 'tipo_motor': 'Parallel-twin', 'peso': 220},
        {'modelo': 'Yamaha XMAX', 'precio': 7500, 'descripcion': 'Scooter urbano versátil', 'imagen': 'xmax.jpg', 'cilindrada': 400, 'potencia': '35 CV', 'stock': 15, 'año': 2022, 'color': 'Azul', 'tipo_motor': 'Monocilíndrico', 'peso': 180},
        {'modelo': 'Yamaha NMAX', 'precio': 4500, 'descripcion': 'Scooter compacto y eficiente', 'imagen': 'nmax.jpg', 'cilindrada': 155, 'potencia': '15 CV', 'stock': 20, 'año': 2023, 'color': 'Negro', 'tipo_motor': 'Monocilíndrico', 'peso': 127},
        {'modelo': 'Yamaha Tricity', 'precio': 6000, 'descripcion': 'Scooter de tres ruedas', 'imagen': 'tricity.jpg', 'cilindrada': 155, 'potencia': '15 CV', 'stock': 10, 'año': 2022, 'color': 'Blanco', 'tipo_motor': 'Monocilíndrico', 'peso': 164},
        {'modelo': 'Yamaha Aerox', 'precio': 3800, 'descripcion': 'Scooter deportivo', 'imagen': 'aerox.jpg', 'cilindrada': 155, 'potencia': '15 CV', 'stock': 25, 'año': 2023, 'color': 'Rojo', 'tipo_motor': 'Monocilíndrico', 'peso': 126}
    ],
    'Touring': [
        {'modelo': 'Yamaha Tracer 9 GT', 'precio': 16500, 'descripcion': 'Touring de alto rendimiento', 'imagen': 'tracer9gt.jpg', 'cilindrada': 890, 'potencia': '119 CV', 'stock': 7, 'año': 2023, 'color': 'Gris', 'tipo_motor': 'Inline-3', 'peso': 220},
        {'modelo': 'Yamaha Tracer 7', 'precio': 10000, 'descripcion': 'Touring versátil', 'imagen': 'tracer7.jpg', 'cilindrada': 689, 'potencia': '74 CV', 'stock': 12, 'año': 2022, 'color': 'Azul', 'tipo_motor': 'Parallel-twin', 'peso': 196},
        {'modelo': 'Yamaha FJR1300', 'precio': 19000, 'descripcion': 'Touring de gran cilindrada', 'imagen': 'fjr1300.jpg', 'cilindrada': 1298, 'potencia': '144 CV', 'stock': 5, 'año': 2023, 'color': 'Negro', 'tipo_motor': 'Inline-4', 'peso': 258},
        {'modelo': 'Yamaha Super Ténéré', 'precio': 17500, 'descripcion': 'Touring trail de aventura', 'imagen': 'supertenere.jpg', 'cilindrada': 1199, 'potencia': '138 CV', 'stock': 6, 'año': 2022, 'color': 'Blanco', 'tipo_motor': 'Parallel-twin', 'peso': 265},
        {'modelo': 'Yamaha Ténéré 700', 'precio': 9500, 'descripcion': 'Trail de aventura compacta', 'imagen': 'tenere700.jpg', 'cilindrada': 689, 'potencia': '74 CV', 'stock': 10, 'año': 2023, 'color': 'Rojo', 'tipo_motor': 'Parallel-twin', 'peso': 204}
    ]
}

with app.app_context():
    for categoria, motos in motos_por_categoria.items():
        for moto_data in motos:
            moto = Moto(
                modelo=moto_data['modelo'],
                categoria=categoria,
                precio=moto_data['precio'],
                descripcion=moto_data['descripcion'],
                imagen=moto_data['imagen'],
                cilindrada=moto_data['cilindrada'],
                potencia=moto_data['potencia'],
                stock=moto_data['stock'],
                año=moto_data['año'],
                color=moto_data['color'],
                tipo_motor=moto_data['tipo_motor'],
                peso=moto_data['peso']
            )
            db.session.add(moto)
    
    db.session.commit()
    print("¡Motos agregadas exitosamente!")
