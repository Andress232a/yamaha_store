import sys
import subprocess

def install_package(package):
    subprocess.check_call([sys.executable, "-m", "pip", "install", package])

def diagnose():
    print("Python executable:", sys.executable)
    print("Python version:", sys.version)
    print("Python path:", sys.path)
    
    try:
        import pymysql
        print("PyMySQL installed successfully")
    except ImportError:
        print("PyMySQL not found. Attempting to install...")
        try:
            install_package("pymysql")
            import pymysql
            print("PyMySQL installed successfully")
        except Exception as e:
            print(f"Failed to install PyMySQL: {e}")

if __name__ == "__main__":
    diagnose()
