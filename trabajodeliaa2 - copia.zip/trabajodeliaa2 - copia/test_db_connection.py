import sys
import os
import traceback
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from app import create_app
from app.models.models import db, Moto
from sqlalchemy import text

def test_database_connection():
    app = create_app()
    
    with app.app_context():
        try:
            # Probar conexión directa
            print("Probando conexión a la base de datos...")
            connection = db.engine.connect()
            
            # Ejecutar consulta de prueba
            result = connection.execute(text("SELECT 1"))
            print("Conexión básica exitosa.")
            
            # Verificar tablas
            inspector = db.inspect(db.engine)
            tables = inspector.get_table_names()
            print("\nTablas en la base de datos:")
            for table in tables:
                print(f"- {table}")
            
            # Intentar contar el número de motos
            moto_count = Moto.query.count()
            print(f"\nNúmero de motos en la base de datos: {moto_count}")
            
            # Mostrar algunas motos como prueba
            if moto_count > 0:
                print("\nMostrando algunas motos:")
                motos = Moto.query.limit(5).all()
                for moto in motos:
                    print(f"- {moto.modelo} ({moto.categoria}): ${moto.precio}")
            else:
                print("\nNo hay motos en la base de datos.")
        
        except Exception as e:
            print("Error detallado al conectar a la base de datos:")
            print(f"Tipo de error: {type(e)}")
            print(f"Mensaje de error: {e}")
            traceback.print_exc()

if __name__ == '__main__':
    test_database_connection()
