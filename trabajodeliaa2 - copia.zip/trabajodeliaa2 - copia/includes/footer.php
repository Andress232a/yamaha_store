<footer class="bg-dark text-white text-center py-3 mt-5">
    <div class="container">
        <p>&copy; 2025 Yamaha Motos. Todos los derechos reservados.</p>
        <small>Sitio web desarrollado con PHP, MySQL y Bootstrap</small>
    </div>
</footer>
