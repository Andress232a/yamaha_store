import sys
import os
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from app import create_app
from app.models.models import db, Moto

def insert_motos():
    app = create_app()
    
    motos_por_categoria = {
        'Deportiva': [
            {'modelo': 'YZF-R1', 'precio': 22500.00, 'descripcion': 'Moto deportiva de alto rendimiento', 'imagen': 'r1.jpg', 'cilindrada': 998, 'potencia': '200 HP'},
            {'modelo': 'YZF-R6', 'precio': 15000.00, 'descripcion': 'Moto deportiva de media cilindrada', 'imagen': 'r6.jpg', 'cilindrada': 600, 'potencia': '120 HP'},
            {'modelo': 'R7', 'precio': 9500.00, 'descripcion': 'Moto deportiva accesible', 'imagen': 'r7.jpg', 'cilindrada': 689, 'potencia': '72 HP'},
            {'modelo': 'R3', 'precio': 5500.00, 'descripcion': 'Moto deportiva para principiantes', 'imagen': 'r3.jpg', 'cilindrada': 321, 'potencia': '42 HP'},
            {'modelo': 'R125', 'precio': 4800.00, 'descripcion': 'Deportiva para jóvenes pilotos', 'imagen': 'r125.jpg', 'cilindrada': 125, 'potencia': '15 HP'}
        ],
        'Naked': [
            {'modelo': 'MT-10', 'precio': 18500.00, 'descripcion': 'Naked de alto rendimiento', 'imagen': 'mt10.jpg', 'cilindrada': 998, 'potencia': '190 HP'},
            {'modelo': 'MT-09', 'precio': 12500.00, 'descripcion': 'Moto naked de estilo agresivo', 'imagen': 'mt09.jpg', 'cilindrada': 890, 'potencia': '115 HP'},
            {'modelo': 'MT-07', 'precio': 7500.00, 'descripcion': 'Naked ligera y ágil', 'imagen': 'mt07.jpg', 'cilindrada': 689, 'potencia': '74 HP'},
            {'modelo': 'MT-03', 'precio': 5200.00, 'descripcion': 'Naked para nuevos conductores', 'imagen': 'mt03.jpg', 'cilindrada': 321, 'potencia': '42 HP'},
            {'modelo': 'MT-125', 'precio': 4500.00, 'descripcion': 'Naked para jóvenes', 'imagen': 'mt125.jpg', 'cilindrada': 125, 'potencia': '15 HP'}
        ],
        'Touring': [
            {'modelo': 'Tracer 9 GT', 'precio': 16500.00, 'descripcion': 'Touring de alto rendimiento', 'imagen': 'tracer9gt.jpg', 'cilindrada': 890, 'potencia': '119 HP'},
            {'modelo': 'Tracer 7', 'precio': 10000.00, 'descripcion': 'Touring versátil', 'imagen': 'tracer7.jpg', 'cilindrada': 689, 'potencia': '74 HP'},
            {'modelo': 'FJR1300', 'precio': 19000.00, 'descripcion': 'Touring de gran cilindrada', 'imagen': 'fjr1300.jpg', 'cilindrada': 1298, 'potencia': '144 HP'},
            {'modelo': 'Super Ténéré', 'precio': 17500.00, 'descripcion': 'Touring trail de aventura', 'imagen': 'supertenere.jpg', 'cilindrada': 1199, 'potencia': '138 HP'},
            {'modelo': 'Ténéré 700', 'precio': 9500.00, 'descripcion': 'Trail de aventura compacta', 'imagen': 'tenere700.jpg', 'cilindrada': 689, 'potencia': '74 HP'}
        ],
        'Scooter': [
            {'modelo': 'TMAX', 'precio': 15000.00, 'descripcion': 'Scooter de alta gama', 'imagen': 'tmax.jpg', 'cilindrada': 560, 'potencia': '55 HP'},
            {'modelo': 'XMAX', 'precio': 7500.00, 'descripcion': 'Scooter urbano versátil', 'imagen': 'xmax.jpg', 'cilindrada': 400, 'potencia': '35 HP'},
            {'modelo': 'NMAX', 'precio': 4500.00, 'descripcion': 'Scooter urbano eficiente', 'imagen': 'nmax.jpg', 'cilindrada': 155, 'potencia': '15 HP'},
            {'modelo': 'Tricity', 'precio': 6000.00, 'descripcion': 'Scooter de tres ruedas', 'imagen': 'tricity.jpg', 'cilindrada': 155, 'potencia': '15 HP'},
            {'modelo': 'Aerox', 'precio': 3800.00, 'descripcion': 'Scooter deportivo', 'imagen': 'aerox.jpg', 'cilindrada': 155, 'potencia': '15 HP'}
        ]
    }
    
    with app.app_context():
        # Eliminar motos existentes
        Moto.query.delete()
        
        # Insertar nuevas motos
        for categoria, motos in motos_por_categoria.items():
            for moto_data in motos:
                moto = Moto(
                    modelo=moto_data['modelo'],
                    categoria=categoria,
                    precio=moto_data['precio'],
                    descripcion=moto_data['descripcion'],
                    imagen=moto_data['imagen'],
                    cilindrada=moto_data['cilindrada'],
                    potencia=moto_data['potencia']
                )
                db.session.add(moto)
        
        db.session.commit()
        print("Motos insertadas exitosamente!")

if __name__ == '__main__':
    insert_motos()
