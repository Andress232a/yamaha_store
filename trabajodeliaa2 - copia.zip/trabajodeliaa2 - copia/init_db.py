from app import create_app
from app.models.models import db

app = create_app()

with app.app_context():
    # Crear todas las tablas
    db.create_all()
    print("Tablas creadas exitosamente")
