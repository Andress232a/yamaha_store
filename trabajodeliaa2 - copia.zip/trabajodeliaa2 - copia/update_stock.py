import sys
from flask import Flask
from app import create_app
from app.models.models import db, Moto

app = create_app()

def update_stock(moto_id, new_stock):
    try:
        moto = Moto.query.get(moto_id)
        if moto:
            moto.stock = new_stock
            db.session.commit()
            print(f'Stock actualizado para {moto.modelo}: {moto.stock}')
        else:
            print('Moto no encontrada')
    except Exception as e:
        print(f'Error al actualizar el stock: {e}')

if __name__ == '__main__':
    try:
        with app.app_context():
            update_stock(1, 10)  # Cambia 1 por el ID correspondiente de YZF-R1
    except Exception as e:
        print(f'Error al iniciar el contexto de la aplicación: {e}')
