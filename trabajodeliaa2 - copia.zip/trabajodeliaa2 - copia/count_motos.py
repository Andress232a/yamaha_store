from app.models.models import db, Moto
from app import create_app

app = create_app()

with app.app_context():
    categorias = db.session.query(Moto.categoria, db.func.count(Moto.id)).group_by(Moto.categoria).all()
    print('Motos por categoría:')
    for categoria, count in categorias:
        print(f'{categoria}: {count} motos')
