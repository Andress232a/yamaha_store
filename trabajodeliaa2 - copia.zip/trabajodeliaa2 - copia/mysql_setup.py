import pymysql
pymysql.install_as_MySQLdb()

def create_database():
    try:
        # Conectar al servidor MySQL
        connection = pymysql.connect(
            host='localhost',
            user='root',  # Cambia esto si tu usuario es diferente
            password='',   # Cambia esto si tienes contraseña
            database='yamaha_motos',
            charset='utf8mb4'
        )
        
        with connection.cursor() as cursor:
            
            # Crear base de datos
            cursor.execute("CREATE DATABASE IF NOT EXISTS yamaha_motos")
            print("Base de datos 'yamaha_motos' creada exitosamente")
            
            # Usar la base de datos
            cursor.execute("USE yamaha_motos")
            
            # Crear tabla de motos
            cursor.execute("""
            CREATE TABLE IF NOT EXISTS motos (
                id INT AUTO_INCREMENT PRIMARY KEY,
                modelo VARCHAR(100) NOT NULL,
                categoria VARCHAR(50) NOT NULL,
                precio DECIMAL(10,2) NOT NULL,
                descripcion TEXT,
                imagen VARCHAR(255),
                cilindrada INT,
                potencia VARCHAR(50),
                stock INT DEFAULT 10,
                año INT,
                color VARCHAR(50),
                tipo_motor VARCHAR(50),
                peso FLOAT
            )
            """)
            print("Tabla 'motos' creada exitosamente")
            
            # Insertar motos de ejemplo
            motos = [
                # Deportivas
                ('YZF-R1', 'Deportiva', 22500.00, 'Moto deportiva de alto rendimiento', 'r1.jpg', 998, '200 HP', 5, 2023, 'Azul', 'Inline-4', 201),
                ('YZF-R6', 'Deportiva', 15000.00, 'Moto deportiva de media cilindrada', 'r6.jpg', 600, '120 HP', 7, 2022, 'Rojo', 'Inline-4', 190),
                ('R7', 'Deportiva', 9500.00, 'Moto deportiva accesible', 'r7.jpg', 689, '72 HP', 10, 2023, 'Gris', 'Parallel-twin', 188),
                ('R3', 'Deportiva', 5500.00, 'Moto deportiva para principiantes', 'r3.jpg', 321, '42 HP', 15, 2023, 'Negro', 'Inline-2', 170),
                ('R125', 'Deportiva', 4800.00, 'Deportiva para jóvenes pilotos', 'r125.jpg', 125, '15 HP', 20, 2023, 'Blanco', 'Monocilíndrico', 140),
                
                # Naked
                ('MT-10', 'Naked', 18500.00, 'Naked de alto rendimiento', 'mt10.jpg', 998, '190 HP', 6, 2023, 'Gris', 'Inline-4', 210),
                ('MT-09', 'Naked', 12500.00, 'Moto naked de estilo agresivo', 'mt09.jpg', 890, '115 HP', 12, 2022, 'Azul', 'Inline-3', 190),
                ('MT-07', 'Naked', 7500.00, 'Naked ligera y ágil', 'mt07.jpg', 689, '74 HP', 15, 2023, 'Blanco', 'Parallel-twin', 182),
                ('MT-03', 'Naked', 5200.00, 'Naked para nuevos conductores', 'mt03.jpg', 321, '42 HP', 18, 2023, 'Negro', 'Monocilíndrico', 168),
                ('MT-125', 'Naked', 4500.00, 'Naked para jóvenes', 'mt125.jpg', 125, '15 HP', 22, 2023, 'Rojo', 'Monocilíndrico', 140),
                
                # Touring
                ('Tracer 9 GT', 'Touring', 16500.00, 'Touring de alto rendimiento', 'tracer9gt.jpg', 890, '119 HP', 7, 2023, 'Gris', 'Inline-3', 220),
                ('Tracer 7', 'Touring', 10000.00, 'Touring versátil', 'tracer7.jpg', 689, '74 HP', 12, 2022, 'Azul', 'Parallel-twin', 196),
                ('FJR1300', 'Touring', 19000.00, 'Touring de gran cilindrada', 'fjr1300.jpg', 1298, '144 HP', 5, 2023, 'Negro', 'Inline-4', 258),
                ('Super Ténéré', 'Touring', 17500.00, 'Touring trail de aventura', 'supertenere.jpg', 1199, '138 HP', 6, 2022, 'Blanco', 'Parallel-twin', 265),
                ('Ténéré 700', 'Touring', 9500.00, 'Trail de aventura compacta', 'tenere700.jpg', 689, '74 HP', 10, 2023, 'Rojo', 'Parallel-twin', 204),
                
                # Scooter
                ('TMAX', 'Scooter', 15000.00, 'Scooter de alta gama', 'tmax.jpg', 560, '55 HP', 8, 2023, 'Gris', 'Parallel-twin', 220),
                ('XMAX', 'Scooter', 7500.00, 'Scooter urbano versátil', 'xmax.jpg', 400, '35 HP', 15, 2022, 'Azul', 'Monocilíndrico', 180),
                ('NMAX', 'Scooter', 4500.00, 'Scooter urbano eficiente', 'nmax.jpg', 155, '15 HP', 20, 2023, 'Negro', 'Monocilíndrico', 127),
                ('Tricity', 'Scooter', 6000.00, 'Scooter de tres ruedas', 'tricity.jpg', 155, '15 HP', 10, 2022, 'Blanco', 'Monocilíndrico', 164),
                ('Aerox', 'Scooter', 3800.00, 'Scooter deportivo', 'aerox.jpg', 155, '15 HP', 25, 2023, 'Rojo', 'Monocilíndrico', 126)
            ]
            
            # Insertar motos
            insert_query = """
            INSERT INTO motos 
            (modelo, categoria, precio, descripcion, imagen, cilindrada, potencia, stock, año, color, tipo_motor, peso) 
            VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
            """
            cursor.executemany(insert_query, motos)
            connection.commit()
            
            print(f"Se insertaron {cursor.rowcount} motos")
            
    except Error as e:
        print(f"Error: {e}")
    
    finally:
        connection.close()
        print("Conexión MySQL cerrada")

if __name__ == '__main__':
    create_database()
