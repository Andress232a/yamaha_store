import sys
import subprocess

def diagnose_pillow():
    print("Python executable:", sys.executable)
    print("Python version:", sys.version)
    print("Python path:", sys.path)
    
    try:
        from PIL import Image
        print("Pillow instalado correctamente")
    except ImportError:
        print("Pillow no encontrado. Intentando instalar...")
        try:
            subprocess.check_call([sys.executable, "-m", "pip", "install", "pillow"])
            from PIL import Image
            print("Pillow instalado exitosamente")
        except Exception as e:
            print(f"Error al instalar Pillow: {e}")

if __name__ == "__main__":
    diagnose_pillow()
