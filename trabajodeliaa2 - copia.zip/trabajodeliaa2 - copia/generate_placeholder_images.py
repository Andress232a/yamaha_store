from PIL import Image, ImageDraw, ImageFont
import os

def create_placeholder_image(filename, text, size=(300, 200), bg_color=(200, 200, 200), text_color=(0, 0, 0)):
    # Crear imagen en blanco
    image = Image.new('RGB', size, bg_color)
    draw = ImageDraw.Draw(image)
    
    # Cargar una fuente
    try:
        font = ImageFont.truetype("arial.ttf", 20)
    except IOError:
        font = ImageFont.load_default()
    
    # Dibujar texto centrado
    text_bbox = draw.textbbox((0, 0), text, font=font)
    text_width = text_bbox[2] - text_bbox[0]
    text_height = text_bbox[3] - text_bbox[1]
    position = ((size[0]-text_width)/2, (size[1]-text_height)/2)
    draw.text(position, text, fill=text_color, font=font)
    
    # Guardar imagen
    image.save(os.path.join('app', 'static', 'img', filename))

def generate_motorcycle_placeholders():
    motos = [
        # Deportivas
        ('r1.jpg', 'YZF-R1'),
        ('r6.jpg', 'YZF-R6'),
        ('r7.jpg', 'R7'),
        ('r3.jpg', 'R3'),
        ('r125.jpg', 'R125'),
        
        # Naked
        ('mt10.jpg', 'MT-10'),
        ('mt09.jpg', 'MT-09'),
        ('mt07.jpg', 'MT-07'),
        ('mt03.jpg', 'MT-03'),
        ('mt125.jpg', 'MT-125'),
        
        # Touring
        ('tracer9gt.jpg', 'Tracer 9 GT'),
        ('tracer7.jpg', 'Tracer 7'),
        ('fjr1300.jpg', 'FJR1300'),
        ('supertenere.jpg', 'Super Ténéré'),
        ('tenere700.jpg', 'Ténéré 700'),
        
        # Scooter
        ('tmax.jpg', 'TMAX'),
        ('xmax.jpg', 'XMAX'),
        ('nmax.jpg', 'NMAX'),
        ('tricity.jpg', 'Tricity'),
        ('aerox.jpg', 'Aerox')
    ]
    
    for filename, text in motos:
        create_placeholder_image(filename, text)
    
    print("Imágenes de marcador de posición generadas.")

if __name__ == '__main__':
    generate_motorcycle_placeholders()
