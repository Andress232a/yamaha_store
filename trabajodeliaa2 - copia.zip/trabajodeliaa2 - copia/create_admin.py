from app import create_app
from app.models.models import db, User, Role

app = create_app()

with app.app_context():
    # Crear roles
    admin_role = Role(name='admin')
    db.session.add(admin_role)
    
    # Crear usuario administrador
    admin_user = User(username='admin', role=admin_role)
    admin_user.set_password('admin123')
    db.session.add(admin_user)
    
    # Crear motos de ejemplo
    motos = [
        {
            'modelo': 'YZF-R1',
            'categoria': 'Deportiva',
            'precio': 15000.00,
            'descripcion': 'Moto deportiva de alta gama',
            'imagen': 'yzf-r1.jpg',
            'cilindrada': 998,
            'potencia': '182 HP',
            'año': 2024,
            'color': 'Azul/Blanco',
            'tipo_motor': '4 cilindros',
            'peso': 197,
            'garantia': '2 años',
            'stock': 10
        },
        {
            'modelo': 'XMAX 300',
            'categoria': 'Scooter',
            'precio': 6800.00,
            'descripcion': 'Maxiscooter urbano de alto rendimiento',
            'imagen': 'xmax300.jpg',
            'cilindrada': 300,
            'potencia': '28 HP',
            'año': 2024,
            'color': 'Gris/Azul',
            'tipo_motor': 'Monocilíndrico',
            'peso': 180,
            'garantia': '2 años',
            'stock': 10
        }
    ]
    
    for moto_data in motos:
        moto = Moto(**moto_data)
        db.session.add(moto)
    
    db.session.commit()
    print("Datos de ejemplo creados exitosamente")
