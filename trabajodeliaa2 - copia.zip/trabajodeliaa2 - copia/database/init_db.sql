CREATE DATABASE IF NOT EXISTS yamaha_motos;
USE yamaha_motos;

-- Tabla de Roles
CREATE TABLE role (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(80) UNIQUE NOT NULL
);

-- Tabla de Usuarios
CREATE TABLE user (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(80) UNIQUE NOT NULL,
    password_hash VARCHAR(120) NOT NULL,
    role_id INT NOT NULL,
    FOREIGN KEY (role_id) REFERENCES role(id)
);

-- Tabla de Motos
CREATE TABLE motos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    modelo VARCHAR(100) NOT NULL,
    categoria VARCHAR(50) NOT NULL,
    precio DECIMAL(10,2) NOT NULL,
    descripcion TEXT,
    imagen VARCHAR(255),
    cilindrada INT,
    potencia VARCHAR(50),
    stock INT DEFAULT 10,
    año INT,
    color VARCHAR(50),
    tipo_motor VARCHAR(50),
    peso FLOAT,
    garantia VARCHAR(100)
);

-- Tabla de Contactos
CREATE TABLE contactos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL,
    telefono VARCHAR(20),
    mensaje TEXT NOT NULL,
    modelo_interes VARCHAR(100),
    fecha_envio TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Tabla de Items de Carrito
CREATE TABLE item_carrito (
    id INT AUTO_INCREMENT PRIMARY KEY,
    moto_id INT NOT NULL,
    cantidad INT NOT NULL DEFAULT 1,
    precio_unitario DECIMAL(10,2) NOT NULL,
    FOREIGN KEY (moto_id) REFERENCES motos(id)
);

-- Tabla de Pedidos
CREATE TABLE pedido (
    id INT AUTO_INCREMENT PRIMARY KEY,
    usuario_nombre VARCHAR(100) NOT NULL,
    usuario_email VARCHAR(100) NOT NULL,
    total DECIMAL(10,2) NOT NULL,
    fecha TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    estado VARCHAR(20) DEFAULT 'Pendiente'
);

-- Tabla de Items de Pedido
CREATE TABLE item_pedido (
    id INT AUTO_INCREMENT PRIMARY KEY,
    pedido_id INT NOT NULL,
    moto_id INT NOT NULL,
    cantidad INT NOT NULL,
    precio_unitario DECIMAL(10,2) NOT NULL,
    FOREIGN KEY (pedido_id) REFERENCES pedido(id),
    FOREIGN KEY (moto_id) REFERENCES motos(id)
);

-- Insertar roles iniciales
INSERT INTO role (name) VALUES ('admin');
INSERT INTO role (name) VALUES ('user');

-- Insertar usuario administrador
INSERT INTO user (username, password_hash, role_id) 
VALUES ('admin', '$2b$12$XvKm1vGqEJqj0LJqJqJqJqJqJqJqJqJqJqJqJqJqJq', 1);
