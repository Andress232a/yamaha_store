CREATE DATABASE IF NOT EXISTS yamaha_motos;
USE yamaha_motos;

CREATE TABLE motos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    modelo VARCHAR(100) NOT NULL,
    categoria VARCHAR(50) NOT NULL,
    precio DECIMAL(10,2) NOT NULL,
    descripcion TEXT,
    imagen VARCHAR(255),
    cilindrada INT,
    potencia VARCHAR(50)
);

INSERT INTO motos (modelo, categoria, precio, descripcion, imagen, cilindrada, potencia) VALUES
-- Deportivas
('YZF-R1', 'Deportiva', 22500.00, 'Moto deportiva de alto rendimiento', 'r1.jpg', 998, '200 HP'),
('YZF-R6', 'Deportiva', 15000.00, 'Moto deportiva de media cilindrada', 'r6.jpg', 600, '120 HP'),
('R7', 'Deportiva', 9500.00, 'Moto deportiva accesible', 'r7.jpg', 689, '72 HP'),
('R3', 'Deportiva', 5500.00, 'Moto deportiva para principiantes', 'r3.jpg', 321, '42 HP'),
('R125', 'Deportiva', 4800.00, 'Deportiva para jóvenes pilotos', 'r125.jpg', 125, '15 HP'),

-- Naked
('MT-10', 'Naked', 18500.00, 'Naked de alto rendimiento', 'mt10.jpg', 998, '190 HP'),
('MT-09', 'Naked', 12500.00, 'Moto naked de estilo agresivo', 'mt09.jpg', 890, '115 HP'),
('MT-07', 'Naked', 7500.00, 'Naked ligera y ágil', 'mt07.jpg', 689, '74 HP'),
('MT-03', 'Naked', 5200.00, 'Naked para nuevos conductores', 'mt03.jpg', 321, '42 HP'),
('MT-125', 'Naked', 4500.00, 'Naked para jóvenes', 'mt125.jpg', 125, '15 HP'),

-- Touring
('Tracer 9 GT', 'Touring', 16500.00, 'Touring de alto rendimiento', 'tracer9gt.jpg', 890, '119 HP'),
('Tracer 7', 'Touring', 10000.00, 'Touring versátil', 'tracer7.jpg', 689, '74 HP'),
('FJR1300', 'Touring', 19000.00, 'Touring de gran cilindrada', 'fjr1300.jpg', 1298, '144 HP'),
('Super Ténéré', 'Touring', 17500.00, 'Touring trail de aventura', 'supertenere.jpg', 1199, '138 HP'),
('Ténéré 700', 'Touring', 9500.00, 'Trail de aventura compacta', 'tenere700.jpg', 689, '74 HP'),

-- Scooter
('TMAX', 'Scooter', 15000.00, 'Scooter de alta gama', 'tmax.jpg', 560, '55 HP'),
('XMAX', 'Scooter', 7500.00, 'Scooter urbano versátil', 'xmax.jpg', 400, '35 HP'),
('NMAX', 'Scooter', 4500.00, 'Scooter urbano eficiente', 'nmax.jpg', 155, '15 HP'),
('Tricity', 'Scooter', 6000.00, 'Scooter de tres ruedas', 'tricity.jpg', 155, '15 HP'),
('Aerox', 'Scooter', 3800.00, 'Scooter deportivo', 'aerox.jpg', 155, '15 HP');

CREATE TABLE contactos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL,
    telefono VARCHAR(20),
    mensaje TEXT NOT NULL,
    fecha_envio TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
