import pymysql

def reset_pedidos():
    try:
        # Conexión a la base de datos
        connection = pymysql.connect(
            host='localhost',
            user='root',
            password='',
            database='yamaha_motos',
            charset='utf8mb4',
            cursorclass=pymysql.cursors.DictCursor
        )

        with connection.cursor() as cursor:
            # Eliminar items de pedido
            cursor.execute("DELETE FROM item_pedido")
            
            # Eliminar pedidos
            cursor.execute("DELETE FROM pedido")
            
            # Restaurar stock a 10
            cursor.execute("UPDATE moto SET stock = 10")
            
        connection.commit()
        print("Base de datos reseteada exitosamente")
        print("- Pedidos eliminados")
        print("- Items de pedido eliminados")
        print("- Stock restaurado a 10 para todas las motos")
        
    except Exception as e:
        print(f"Error al resetear la base de datos: {e}")
    finally:
        connection.close()

if __name__ == '__main__':
    reset_pedidos()
