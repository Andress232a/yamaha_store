import os
import shutil
import sys

def reset_migrations():
    # Ruta a la carpeta de migraciones
    migrations_folder = os.path.join(os.path.dirname(__file__), 'migrations')
    
    # Eliminar carpeta de migraciones si existe
    if os.path.exists(migrations_folder):
        shutil.rmtree(migrations_folder)
        print("Carpeta de migraciones eliminada.")
    
    # Inicializar nuevas migraciones
    os.system(f"{sys.executable} -m flask db init")
    os.system(f"{sys.executable} -m flask db migrate -m 'Initial migration'")
    os.system(f"{sys.executable} -m flask db upgrade")
    
    print("Migraciones reiniciadas exitosamente.")

if __name__ == '__main__':
    reset_migrations()
