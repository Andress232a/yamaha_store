import os
import requests

def download_image(url, filename):
    try:
        response = requests.get(url)
        if response.status_code == 200:
            filepath = os.path.join('app', 'static', 'img', filename)
            with open(filepath, 'wb') as file:
                file.write(response.content)
            print(f"Descargada: {filename}")
            return True
        else:
            print(f"Error descargando {filename}: {response.status_code}")
            return False
    except Exception as e:
        print(f"Error descargando {filename}: {e}")
        return False

def download_yamaha_images():
    # URLs de imágenes de Yamaha (actualiza estas URLs con imágenes reales)
    images = {
        # Deportivas
        'r1.jpg': 'https://www.yamahamotorsports.com/sport-bike/images/YZF-R1-2023-hero.jpg',
        'r6.jpg': 'https://www.yamahamotorsports.com/sport-bike/images/YZF-R6-2023-hero.jpg',
        'r7.jpg': 'https://www.yamahamotorsports.com/sport-bike/images/YZF-R7-2023-hero.jpg',
        'r3.jpg': 'https://www.yamahamotorsports.com/sport-bike/images/YZF-R3-2023-hero.jpg',
        'r125.jpg': 'https://www.yamahamotorsports.com/sport-bike/images/YZF-R125-2023-hero.jpg',

        # Naked
        'mt10.jpg': 'https://www.yamahamotorsports.com/naked/images/MT-10-2023-hero.jpg',
        'mt09.jpg': 'https://www.yamahamotorsports.com/naked/images/MT-09-2023-hero.jpg',
        'mt07.jpg': 'https://www.yamahamotorsports.com/naked/images/MT-07-2023-hero.jpg',
        'mt03.jpg': 'https://www.yamahamotorsports.com/naked/images/MT-03-2023-hero.jpg',
        'mt125.jpg': 'https://www.yamahamotorsports.com/naked/images/MT-125-2023-hero.jpg',

        # Touring
        'tracer9gt.jpg': 'https://www.yamahamotorsports.com/sport-touring/images/Tracer-9-GT-2023-hero.jpg',
        'tracer7.jpg': 'https://www.yamahamotorsports.com/sport-touring/images/Tracer-7-2023-hero.jpg',
        'fjr1300.jpg': 'https://www.yamahamotorsports.com/sport-touring/images/FJR1300-2023-hero.jpg',
        'supertenere.jpg': 'https://www.yamahamotorsports.com/adventure/images/Super-Tenere-2023-hero.jpg',
        'tenere700.jpg': 'https://www.yamahamotorsports.com/adventure/images/Tenere-700-2023-hero.jpg',

        # Scooter
        'tmax.jpg': 'https://www.yamahamotorsports.com/scooter/images/TMAX-2023-hero.jpg',
        'xmax.jpg': 'https://www.yamahamotorsports.com/scooter/images/XMAX-2023-hero.jpg',
        'nmax.jpg': 'https://www.yamahamotorsports.com/scooter/images/NMAX-2023-hero.jpg',
        'tricity.jpg': 'https://www.yamahamotorsports.com/scooter/images/Tricity-2023-hero.jpg',
        'aerox.jpg': 'https://www.yamahamotorsports.com/scooter/images/Aerox-2023-hero.jpg'
    }

    # Crear directorio de imágenes si no existe
    os.makedirs(os.path.join('app', 'static', 'img'), exist_ok=True)

    # Descargar imágenes
    for filename, url in images.items():
        download_image(url, filename)

if __name__ == '__main__':
    download_yamaha_images()
