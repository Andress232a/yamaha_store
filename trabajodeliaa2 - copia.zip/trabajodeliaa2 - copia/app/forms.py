from flask_wtf import FlaskForm
from wtforms import StringField, TextAreaField, SubmitField, IntegerField, SelectField, PasswordField
from wtforms.validators import DataRequired, Email, Length, NumberRange

class LoginForm(FlaskForm):
    username = StringField('Nombre de usuario', validators=[DataRequired()])
    password = PasswordField('Contraseña', validators=[DataRequired()])
    submit = SubmitField('Iniciar sesión')

class RegisterForm(FlaskForm):
    username = StringField('Nombre de usuario', validators=[DataRequired(), Length(min=4, max=80)])
    password = PasswordField('Contraseña', validators=[DataRequired()])
    submit = SubmitField('Registrar')

class ContactoForm(FlaskForm):
    nombre = StringField('Nombre', validators=[DataRequired(), Length(min=2, max=100)])
    email = StringField('Email', validators=[DataRequired(), Email()])
    telefono = StringField('Teléfono', validators=[Length(max=20)])
    modelo = StringField('Modelo de Interés')
    mensaje = TextAreaField('Mensaje', validators=[DataRequired(), Length(min=10, max=500)])
    submit = SubmitField('Enviar Mensaje')

class AgregarCarritoForm(FlaskForm):
    cantidad = IntegerField('Cantidad', validators=[DataRequired(), NumberRange(min=1, max=10)], default=1)
    submit = SubmitField('Agregar al Carrito')

class FinalizarCompraForm(FlaskForm):
    nombre = StringField('Nombre Completo', validators=[DataRequired(), Length(min=2, max=100)])
    email = StringField('Email', validators=[DataRequired(), Email()])
    direccion = StringField('Dirección de Entrega', validators=[DataRequired(), Length(min=5, max=200)])
    metodo_pago = SelectField('Método de Pago', choices=[
        ('transferencia', 'Transferencia Bancaria'),
        ('tarjeta', 'Tarjeta de Crédito/Débito'),
        ('paypal', 'PayPal')
    ], validators=[DataRequired()])
    submit = SubmitField('Finalizar Compra')
