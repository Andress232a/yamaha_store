// Animación de carga y manejo de botones hero
window.addEventListener('load', function() {
    const loadingScreen = document.querySelector('.loading-screen');
    if (loadingScreen) {
        loadingScreen.style.display = 'none';
    }

    // Manejo del mensaje de bienvenida
    const welcomeMessage = document.querySelector('.welcome-message');
    if (welcomeMessage) {
        // Solo mostrar el mensaje de bienvenida en la página de inicio
        if (window.location.pathname === '/') {
            // Solo mostrar en la primera carga
            if (!sessionStorage.getItem('firstLoad')) {
                sessionStorage.setItem('firstLoad', 'true');
                welcomeMessage.style.display = 'block';
            } else {
                welcomeMessage.style.display = 'none';
            }
        } else {
            // En otras páginas, siempre ocultar el mensaje
            welcomeMessage.style.display = 'none';
        }

        // Al hacer clic en cualquier parte, ocultar el mensaje
        welcomeMessage.addEventListener('click', function() {
            this.style.display = 'none';
        });
    }

    // Manejo de todos los enlaces de la página
    const allLinks = document.querySelectorAll('a');
    allLinks.forEach(link => {
        link.addEventListener('click', function(e) {
            e.preventDefault();
            const url = this.getAttribute('href');
            
            // Si es un enlace interno (con #)
            if (url.includes('#')) {
                window.location.href = url;
            } else {
                // Para todos los demás enlaces, redirigir a la sección de motos
                window.location.href = url + '#motos';
            }
        });
    });

    // Manejo de navegación del historial
    window.addEventListener('popstate', function(e) {
        // Cuando se usa el botón atrás, mantener la vista en la sección de motos
        if (window.location.pathname === '/') {
            window.location.href = '#motos';
        }
    });

    // Manejo de enlaces de detalles de motos
    const motoDetailsLinks = document.querySelectorAll('.moto-card .btn');
    motoDetailsLinks.forEach(link => {
        link.addEventListener('click', function(e) {
            e.preventDefault();
            const url = this.getAttribute('href');
            // Guardar el estado actual antes de navegar
            history.pushState(null, null, '#motos');
            window.location.href = url;
        });
    });

    // Animación de elementos al hacer scroll
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('animate__animated', 'animate__fadeInUp');
            }
        });
    }, {
        threshold: 0.1
    });

    // Observar elementos con la clase .fade-in
    document.querySelectorAll('.fade-in').forEach((el) => {
        observer.observe(el);
    });
});

// Animación de tarjetas al hacer hover
document.querySelectorAll('.card').forEach(card => {
    card.addEventListener('mouseenter', () => {
        card.style.transform = 'translateY(-10px)';
        card.style.boxShadow = '0 10px 20px rgba(0,0,0,0.2)';
    });

    card.addEventListener('mouseleave', () => {
        card.style.transform = 'translateY(0)';
        card.style.boxShadow = '0 2px 10px rgba(0,0,0,0.1)';
    });
});

// Animación de botones al hacer click
document.querySelectorAll('.btn').forEach(btn => {
    btn.addEventListener('click', () => {
        btn.style.transform = 'scale(0.95)';
        setTimeout(() => {
            btn.style.transform = 'scale(1)';
        }, 200);
    });
});

// Animación de navegación al hacer scroll
window.addEventListener('scroll', () => {
    const navbar = document.querySelector('.navbar');
    if (window.scrollY > 50) {
        navbar.style.background = 'rgba(0, 114, 206, 0.95)';
        navbar.style.boxShadow = '0 2px 10px rgba(0,0,0,0.2)';
    } else {
        navbar.style.background = 'rgba(0, 114, 206, 0.7)';
        navbar.style.boxShadow = 'none';
    }
});
