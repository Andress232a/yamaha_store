from flask import Flask
from flask_sqlalchemy import SQLAlchemy
from flask_migrate import Migrate
from flask_login import LoginManager
from config import Config

# Creamos las instancias de las extensiones
db = SQLAlchemy()
migrate = Migrate()
login_manager = LoginManager()

@login_manager.user_loader
def load_user(id):
    from app.models.models import User
    return User.query.get(int(id))

def create_app(config_class=Config):
    app = Flask(__name__)
    app.config.from_object(config_class)

    # Inicializar las extensiones
    db.init_app(app)
    migrate.init_app(app, db)
    login_manager.init_app(app)
    login_manager.login_view = 'auth.login'

    with app.app_context():
        # Eliminar todas las tablas existentes
        db.drop_all()
        
        # Crear las tablas nuevamente
        db.create_all()
        
        # Crear roles
        from app.models.models import Role
        admin_role = Role(name='admin')
        db.session.add(admin_role)
        
        # Crear usuario administrador
        from app.models.models import User
        admin_user = User(username='admin', role=admin_role)
        admin_user.set_password('admin123')
        db.session.add(admin_user)
        
        # Crear motos de ejemplo
        from app.models.models import Moto
        motos = [
            {
                'modelo': 'YZF-R1',
                'categoria': 'Deportiva',
                'precio': 15000.00,
                'descripcion': 'Moto deportiva de alta gama',
                'imagen': 'r1.jpg',
                'cilindrada': 998,
                'potencia': '182 HP',
                'año': 2024,
                'color': 'Azul/Blanco',
                'tipo_motor': '4 cilindros',
                'peso': 197,
                'garantia': '2 años',
                'stock': 10
            },
            {
                'modelo': 'XMAX',
                'categoria': 'Scooter',
                'precio': 6800.00,
                'descripcion': 'Maxiscooter urbano de alto rendimiento',
                'imagen': 'xmax.jpg',
                'cilindrada': 300,
                'potencia': '28 HP',
                'año': 2024,
                'color': 'Gris/Azul',
                'tipo_motor': 'Monocilíndrico',
                'peso': 180,
                'garantia': '2 años',
                'stock': 10
            },
            {
                'modelo': 'MT-09',
                'categoria': 'Naked',
                'precio': 12500.00,
                'descripcion': 'Moto naked de alta gama',
                'imagen': 'mt09.jpg',
                'cilindrada': 847,
                'potencia': '117 HP',
                'año': 2024,
                'color': 'Negro/Rojo',
                'tipo_motor': '3 cilindros',
                'peso': 197,
                'garantia': '2 años',
                'stock': 15
            },
            {
                'modelo': 'TMAX',
                'categoria': 'Scooter',
                'precio': 9500.00,
                'descripcion': 'Maxiscooter de alta gama',
                'imagen': 'tmax.jpg',
                'cilindrada': 562,
                'potencia': '55 HP',
                'año': 2024,
                'color': 'Blanco',
                'tipo_motor': '2 cilindros',
                'peso': 237,
                'garantia': '2 años',
                'stock': 8
            },
            {
                'modelo': 'YZF-R3',
                'categoria': 'Deportiva',
                'precio': 7500.00,
                'descripcion': 'Moto deportiva compacta',
                'imagen': 'r3.jpg',
                'cilindrada': 321,
                'potencia': '42 HP',
                'año': 2024,
                'color': 'Azul/Negro',
                'tipo_motor': '2 cilindros',
                'peso': 169,
                'garantia': '2 años',
                'stock': 20
            },
            {
                'modelo': 'YZF-R6',
                'categoria': 'Deportiva',
                'precio': 11000.00,
                'descripcion': 'Moto deportiva de media cilindrada',
                'imagen': 'r6.jpg',
                'cilindrada': 599,
                'potencia': '117 HP',
                'año': 2024,
                'color': 'Azul/Negro',
                'tipo_motor': '4 cilindros',
                'peso': 173,
                'garantia': '2 años',
                'stock': 12
            },
            {
                'modelo': 'YZF-R7',
                'categoria': 'Deportiva',
                'precio': 8500.00,
                'descripcion': 'Moto deportiva de entrada',
                'imagen': 'r7.jpg',
                'cilindrada': 700,
                'potencia': '73 HP',
                'año': 2024,
                'color': 'Azul/Negro',
                'tipo_motor': '2 cilindros',
                'peso': 177,
                'garantia': '2 años',
                'stock': 18
            },
            {
                'modelo': 'MT-07',
                'categoria': 'Naked',
                'precio': 9500.00,
                'descripcion': 'Moto naked de media cilindrada',
                'imagen': 'mt07.jpg',
                'cilindrada': 689,
                'potencia': '74 HP',
                'año': 2024,
                'color': 'Negro/Blanco',
                'tipo_motor': '2 cilindros',
                'peso': 182,
                'garantia': '2 años',
                'stock': 14
            },
            {
                'modelo': 'MT-10',
                'categoria': 'Naked',
                'precio': 13500.00,
                'descripcion': 'Moto naked de alta gama',
                'imagen': 'mt10.jpg',
                'cilindrada': 998,
                'potencia': '117 HP',
                'año': 2024,
                'color': 'Azul/Negro',
                'tipo_motor': '4 cilindros',
                'peso': 200,
                'garantia': '2 años',
                'stock': 10
            },
            {
                'modelo': 'MT-125',
                'categoria': 'Naked',
                'precio': 5500.00,
                'descripcion': 'Moto naked de entrada',
                'imagen': 'mt125.jpg',
                'cilindrada': 125,
                'potencia': '15 HP',
                'año': 2024,
                'color': 'Azul/Negro',
                'tipo_motor': 'Monocilíndrico',
                'peso': 136,
                'garantia': '2 años',
                'stock': 25
            },
            {
                'modelo': 'NMAX',
                'categoria': 'Scooter',
                'precio': 4500.00,
                'descripcion': 'Scooter urbano',
                'imagen': 'nmax.jpg',
                'cilindrada': 125,
                'potencia': '12 HP',
                'año': 2024,
                'color': 'Azul/Negro',
                'tipo_motor': 'Monocilíndrico',
                'peso': 125,
                'garantia': '2 años',
                'stock': 30
            },
            {
                'modelo': 'YZF-R125',
                'categoria': 'Deportiva',
                'precio': 6500.00,
                'descripcion': 'Moto deportiva de entrada',
                'imagen': 'r125.jpg',
                'cilindrada': 125,
                'potencia': '15 HP',
                'año': 2024,
                'color': 'Azul/Negro',
                'tipo_motor': 'Monocilíndrico',
                'peso': 138,
                'garantia': '2 años',
                'stock': 22
            },
            {
                'modelo': 'FJR1300',
                'categoria': 'Touring',
                'precio': 18000.00,
                'descripcion': 'Moto de turismo de alta gama',
                'imagen': 'fjr1300.jpg',
                'cilindrada': 1298,
                'potencia': '148 HP',
                'año': 2024,
                'color': 'Azul/Negro',
                'tipo_motor': '4 cilindros',
                'peso': 275,
                'garantia': '2 años',
                'stock': 8
            },
            {
                'modelo': 'Tracer 9',
                'categoria': 'Touring',
                'precio': 14000.00,
                'descripcion': 'Moto de turismo deportiva',
                'imagen': 'tracer9gt.jpg',
                'cilindrada': 890,
                'potencia': '117 HP',
                'año': 2024,
                'color': 'Azul/Negro',
                'tipo_motor': '3 cilindros',
                'peso': 210,
                'garantia': '2 años',
                'stock': 12
            },
            {
                'modelo': 'Tracer 9 GT',
                'categoria': 'Touring',
                'precio': 16000.00,
                'descripcion': 'Moto de turismo deportiva con equipamiento GT',
                'imagen': 'tracer9gt.jpg',
                'cilindrada': 890,
                'potencia': '117 HP',
                'año': 2024,
                'color': 'Azul/Negro',
                'tipo_motor': '3 cilindros',
                'peso': 215,
                'garantia': '2 años',
                'stock': 10
            },
            {
                'modelo': 'Tenere 700',
                'categoria': 'Enduro',
                'precio': 12000.00,
                'descripcion': 'Moto de aventura',
                'imagen': 'tenere700.jpg',
                'cilindrada': 689,
                'potencia': '74 HP',
                'año': 2024,
                'color': 'Azul/Negro',
                'tipo_motor': '2 cilindros',
                'peso': 193,
                'garantia': '2 años',
                'stock': 15
            },
            {
                'modelo': 'Super Ténéré',
                'categoria': 'Enduro',
                'precio': 13500.00,
                'descripcion': 'Moto de aventura de alta gama',
                'imagen': 'supertenere.jpg',
                'cilindrada': 1200,
                'potencia': '118 HP',
                'año': 2024,
                'color': 'Azul/Negro',
                'tipo_motor': '2 cilindros',
                'peso': 240,
                'garantia': '2 años',
                'stock': 8
            },
            {
                'modelo': 'Tricity',
                'categoria': 'Scooter',
                'precio': 7500.00,
                'descripcion': 'Scooter triciclo',
                'imagen': 'tricity.jpg',
                'cilindrada': 250,
                'potencia': '20 HP',
                'año': 2024,
                'color': 'Azul/Negro',
                'tipo_motor': 'Monocilíndrico',
                'peso': 165,
                'garantia': '2 años',
                'stock': 12
            },
            {
                'modelo': 'Aerox',
                'categoria': 'Scooter',
                'precio': 5000.00,
                'descripcion': 'Scooter deportivo',
                'imagen': 'aerox.jpg',
                'cilindrada': 155,
                'potencia': '15 HP',
                'año': 2024,
                'color': 'Azul/Negro',
                'tipo_motor': 'Monocilíndrico',
                'peso': 120,
                'garantia': '2 años',
                'stock': 20
            }
        ]
        
        for moto_data in motos:
            moto = Moto(**moto_data)
            db.session.add(moto)
        
        db.session.commit()
        print("Base de datos inicializada exitosamente")

    from app.routes import init_routes
    from app.models import models
    
    init_routes(app)
    return app
