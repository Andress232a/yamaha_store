from flask import render_template, flash, redirect, url_for, session, request, current_app
from flask_login import login_user, logout_user, login_required, current_user
from app.models.models import db, Moto, Contacto, ItemCarrito, Pedido, ItemPedido, User, Role
from app.forms import ContactoForm, AgregarCarritoForm, FinalizarCompraForm, LoginForm, RegisterForm

def init_routes(app):
    @app.route('/')
    def index():
        # Obtener parámetros de filtro
        categoria = request.args.get('categoria')
        precio_min = request.args.get('precio_min', type=float)
        precio_max = request.args.get('precio_max', type=float)

        # Consulta base
        query = Moto.query

        # Filtro por categoría
        if categoria:
            query = query.filter(Moto.categoria == categoria)

        # Filtro por rango de precio
        if precio_min is not None:
            query = query.filter(Moto.precio >= precio_min)
        if precio_max is not None:
            query = query.filter(Moto.precio <= precio_max)

        # Obtener categorías únicas para el menú de filtros
        categorias = db.session.query(Moto.categoria.distinct()).all()
        categorias = [cat[0] for cat in categorias]

        # Obtener motos filtradas
        motos = query.all()

        return render_template('index.html', motos=motos, categorias=categorias)

    @app.route('/moto/<int:moto_id>', methods=['GET', 'POST'])
    def moto(moto_id):
        moto = Moto.query.get_or_404(moto_id)
        form = AgregarCarritoForm()
        
        if form.validate_on_submit():
            if 'carrito' not in session:
                session['carrito'] = []
            
            item = {
                'moto_id': moto_id,
                'cantidad': form.cantidad.data
            }
            session['carrito'].append(item)
            session.modified = True
            print(f"DEBUG: Carrito actual: {session['carrito']}")  # Log para depuración
            flash('Producto agregado al carrito', 'success')
            
            # Mantener la posición de la página
            scroll_position = request.args.get('scroll_position', 0)
            return redirect(url_for('moto', moto_id=moto_id, scroll_position=scroll_position))
        
        return render_template('detalle_moto.html', moto=moto, form=form)

    @app.route('/carrito')
    def carrito():
        carrito = session.get('carrito', [])
        total = 0
        items = []
        
        for item in carrito:
            moto = Moto.query.get(item['moto_id'])
            if moto:
                subtotal = moto.precio * item['cantidad']
                total += subtotal
                items.append({
                    'moto': moto,
                    'cantidad': item['cantidad'],
                    'subtotal': subtotal
                })
        
        return render_template('carrito.html', motos=items, total=total)

    @app.route('/carrito/eliminar/<int:moto_id>', methods=['POST'])
    def eliminar_item(moto_id):
        carrito = session.get('carrito', [])
        carrito = [item for item in carrito if item['moto_id'] != moto_id]
        session['carrito'] = carrito
        session.modified = True
        flash('Producto eliminado del carrito', 'success')
        
        # Mantener la posición de la página
        scroll_position = request.args.get('scroll_position', 0)
        return redirect(url_for('carrito', scroll_position=scroll_position))

    @app.route('/finalizar_compra', methods=['GET', 'POST'])
    def finalizar_compra():
        carrito = session.get('carrito', [])
        if not carrito:
            flash('El carrito está vacío', 'danger')
            
            # Mantener la posición de la página
            scroll_position = request.args.get('scroll_position', 0)
            return redirect(url_for('index', scroll_position=scroll_position))
            
        form = FinalizarCompraForm()
        if form.validate_on_submit():
            total = 0
            for item in carrito:
                moto = Moto.query.get(item['moto_id'])
                if moto:
                    total += moto.precio * item['cantidad']
            
            # Crear pedido
            pedido = Pedido(
                usuario_nombre=form.nombre.data,
                usuario_email=form.email.data,
                total=total
            )
            db.session.add(pedido)
            db.session.flush()  # Obtener ID del pedido
            
            # Crear items de pedido
            for item in carrito:
                moto = Moto.query.get(item['moto_id'])
                item_pedido = ItemPedido(
                    pedido_id=pedido.id,
                    moto_id=moto.id,
                    cantidad=item['cantidad'],
                    precio_unitario=moto.precio
                )
                db.session.add(item_pedido)
                
                # Reducir stock
                if moto.stock is not None and moto.stock >= item['cantidad']:
                    moto.stock -= item['cantidad']
                else:
                    flash(f'Error: stock insuficiente para {moto.modelo}.', 'danger')
                    return redirect(url_for('index'))
            
            db.session.commit()
            
            # Limpiar carrito
            session.pop('carrito', None)
            
            flash(f'¡Compra realizada con éxito! Número de pedido: {pedido.id}', 'success')
            return redirect(url_for('index'))
        
        return render_template('finalizar_compra.html', form=form)

    @app.route('/pedidos')
    @login_required
    def pedidos():
        if not current_user.is_admin():
            flash('No tienes permisos para acceder a esta página', 'danger')
            return redirect(url_for('index'))
        
        pedidos = Pedido.query.order_by(Pedido.fecha.desc()).all()
        return render_template('pedidos.html', pedidos=pedidos)

    @app.route('/limpiar_pedidos', methods=['POST'])
    @login_required
    def limpiar_pedidos():
        if not current_user.is_admin():
            flash('No tienes permisos para realizar esta acción', 'danger')
            return redirect(url_for('index'))
        
        try:
            # Primero obtener todos los pedidos entregados
            pedidos_entregados = Pedido.query.filter_by(estado='Entregado').all()
            
            # Para cada pedido, eliminar sus items primero
            for pedido in pedidos_entregados:
                ItemPedido.query.filter_by(pedido_id=pedido.id).delete()
                
            # Ahora eliminar los pedidos
            Pedido.query.filter_by(estado='Entregado').delete()
            
            db.session.commit()
            flash('Pedidos entregados eliminados exitosamente', 'success')
        except Exception as e:
            db.session.rollback()
            flash(f'Error al eliminar pedidos: {str(e)}', 'danger')
        
        return redirect(url_for('pedidos'))

    @app.route('/api/pedido/<int:pedido_id>/estado', methods=['PUT'])
    @login_required
    def cambiar_estado_pedido(pedido_id):
        if not current_user.is_admin():
            return {'success': False, 'message': 'No tienes permisos para realizar esta acción'}, 403
        
        pedido = Pedido.query.get_or_404(pedido_id)
        data = request.get_json()
        
        if 'estado' in data:
            pedido.estado = data['estado']
            db.session.commit()
            return {'success': True, 'estado': pedido.estado}
        
        return {'success': False, 'message': 'No se proporcionó un estado'}, 400

    @app.route('/auth/login', methods=['GET', 'POST'])
    def login():
        if current_user.is_authenticated:
            return redirect(url_for('index'))
        
        form = LoginForm()
        if form.validate_on_submit():
            user = User.query.filter_by(username=form.username.data).first()
            if user and user.check_password(form.password.data):
                login_user(user)
                return redirect(url_for('pedidos'))
            flash('Nombre de usuario o contraseña inválidos', 'danger')
        return render_template('login.html', form=form)

    @app.route('/register', methods=['GET', 'POST'])
    def register():
        if current_user.is_authenticated:
            return redirect(url_for('index'))
        
        form = RegisterForm()
        if form.validate_on_submit():
            admin_role = Role.query.filter_by(name='admin').first()
            if not admin_role:
                admin_role = Role(name='admin')
                db.session.add(admin_role)
                db.session.commit()
            
            user = User(username=form.username.data, role=admin_role)
            user.set_password(form.password.data)
            db.session.add(user)
            db.session.commit()
            flash('Registro exitoso. Ahora puedes iniciar sesión.', 'success')
            return redirect(url_for('auth.login'))
        return render_template('register.html', form=form)

    @app.route('/logout')
    @login_required
    def logout():
        logout_user()
        return redirect(url_for('index'))
        logout_user()
        return redirect(url_for('index'))

    @app.route('/contacto', methods=['GET', 'POST'])
    def contacto():
        form = ContactoForm()
        if form.validate_on_submit():
            nuevo_contacto = Contacto(
                nombre=form.nombre.data,
                email=form.email.data,
                telefono=form.telefono.data,
                mensaje=form.mensaje.data
            )
            db.session.add(nuevo_contacto)
            db.session.commit()
            flash('Mensaje enviado exitosamente', 'success')
            return redirect(url_for('index'))
        return render_template('contacto.html', form=form)

    @app.route('/contacto/<modelo>', methods=['GET', 'POST'])
    def contacto_moto(modelo):
        form = ContactoForm()
        if form.validate_on_submit():
            nuevo_contacto = Contacto(
                nombre=form.nombre.data,
                email=form.email.data,
                telefono=form.telefono.data,
                mensaje=form.mensaje.data
            )
            db.session.add(nuevo_contacto)
            db.session.commit()
            flash('Mensaje enviado exitosamente', 'success')
            return redirect(url_for('index'))
        return render_template('contacto.html', form=form)

    return None
