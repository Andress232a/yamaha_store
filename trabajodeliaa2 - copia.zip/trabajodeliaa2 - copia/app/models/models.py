from flask_sqlalchemy import SQLAlchemy
from datetime import datetime
from werkzeug.security import generate_password_hash, check_password_hash
from flask_login import UserMixin, LoginManager
from app import db

# La instancia de db se importará desde __init__.py

# La instancia de db se importará desde __init__.py

class Role(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(80), unique=True)
    users = db.relationship('User', backref='role', lazy=True)

class User(UserMixin, db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False)
    password_hash = db.Column(db.String(120), nullable=False)
    role_id = db.Column(db.Integer, db.ForeignKey('role.id'), nullable=False)

    def set_password(self, password):
        self.password_hash = generate_password_hash(password)

    def check_password(self, password):
        return check_password_hash(self.password_hash, password)

    def is_admin(self):
        return self.role.name == 'admin'

class Moto(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    modelo = db.Column(db.String(100), nullable=False)
    categoria = db.Column(db.String(50), nullable=False)
    precio = db.Column(db.Float, nullable=False)
    descripcion = db.Column(db.Text)
    imagen = db.Column(db.String(255))
    cilindrada = db.Column(db.Integer)
    potencia = db.Column(db.String(50))
    stock = db.Column(db.Integer, default=10)
    año = db.Column(db.Integer)
    color = db.Column(db.String(50))
    tipo_motor = db.Column(db.String(50))
    peso = db.Column(db.Float)
    garantia = db.Column(db.String(100))

    def to_dict(self):
        return {
            'id': self.id,
            'modelo': self.modelo,
            'precio': self.precio,
            'imagen': self.imagen
        }

class Contacto(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    nombre = db.Column(db.String(100), nullable=False)
    email = db.Column(db.String(100), nullable=False)
    telefono = db.Column(db.String(20))
    mensaje = db.Column(db.Text, nullable=False)
    modelo_interes = db.Column(db.String(100))
    fecha_envio = db.Column(db.DateTime, default=datetime.utcnow)

class ItemCarrito(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    moto_id = db.Column(db.Integer, db.ForeignKey('moto.id'), nullable=False)
    cantidad = db.Column(db.Integer, nullable=False, default=1)
    precio_unitario = db.Column(db.Float, nullable=False)
    moto = db.relationship('Moto', backref=db.backref('carrito_items', lazy=True))

    def calcular_total(self):
        return self.cantidad * self.precio_unitario
    id = db.Column(db.Integer, primary_key=True)
    moto_id = db.Column(db.Integer, db.ForeignKey('moto.id'), nullable=False)
    cantidad = db.Column(db.Integer, nullable=False, default=1)
    precio_unitario = db.Column(db.Float, nullable=False)
    moto = db.relationship('Moto', backref=db.backref('carrito_items', lazy=True))

class Pedido(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    usuario_nombre = db.Column(db.String(100), nullable=False)
    usuario_email = db.Column(db.String(100), nullable=False)
    total = db.Column(db.Float, nullable=False)
    fecha = db.Column(db.DateTime, default=datetime.utcnow)
    estado = db.Column(db.String(20), default='Pendiente')
    items = db.relationship('ItemPedido', backref='pedido', lazy=True, cascade='all, delete-orphan')

class ItemPedido(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    pedido_id = db.Column(db.Integer, db.ForeignKey('pedido.id'), nullable=False)
    moto_id = db.Column(db.Integer, db.ForeignKey('moto.id'), nullable=False)
    cantidad = db.Column(db.Integer, nullable=False)
    precio_unitario = db.Column(db.Float, nullable=False)
    moto = db.relationship('Moto', backref='pedidos_items')
