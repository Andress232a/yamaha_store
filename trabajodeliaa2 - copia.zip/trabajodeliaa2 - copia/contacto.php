<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Contacto - Yamaha Motos</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <?php 
    include 'database/config.php';
    include 'includes/header.php'; 
    
    $modelo_seleccionado = $_GET['modelo'] ?? '';

    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $nombre = $conexion->real_escape_string($_POST['nombre']);
        $email = $conexion->real_escape_string($_POST['email']);
        $telefono = $conexion->real_escape_string($_POST['telefono']);
        $mensaje = $conexion->real_escape_string($_POST['mensaje']);
        $modelo = $conexion->real_escape_string($_POST['modelo']);

        $consulta = "INSERT INTO contactos (nombre, email, telefono, mensaje) VALUES ('$nombre', '$email', '$telefono', '$mensaje')";
        
        if ($conexion->query($consulta)) {
            $mensaje_enviado = "Mensaje enviado con éxito. Nos pondremos en contacto pronto.";
        } else {
            $error = "Error al enviar el mensaje: " . $conexion->error;
        }
    }
    ?>

    <div class="container mt-5">
        <h1>Contacto Yamaha Motos</h1>
        
        <?php if (isset($mensaje_enviado)): ?>
            <div class="alert alert-success"><?php echo $mensaje_enviado; ?></div>
        <?php endif; ?>

        <?php if (isset($error)): ?>
            <div class="alert alert-danger"><?php echo $error; ?></div>
        <?php endif; ?>

        <form method="POST">
            <div class="mb-3">
                <label class="form-label">Modelo de Interés</label>
                <input type="text" class="form-control" name="modelo" value="<?php echo htmlspecialchars($modelo_seleccionado); ?>" required>
            </div>
            <div class="mb-3">
                <label class="form-label">Nombre</label>
                <input type="text" class="form-control" name="nombre" required>
            </div>
            <div class="mb-3">
                <label class="form-label">Email</label>
                <input type="email" class="form-control" name="email" required>
            </div>
            <div class="mb-3">
                <label class="form-label">Teléfono</label>
                <input type="tel" class="form-control" name="telefono">
            </div>
            <div class="mb-3">
                <label class="form-label">Mensaje</label>
                <textarea class="form-control" name="mensaje" rows="4" required></textarea>
            </div>
            <button type="submit" class="btn btn-primary">Enviar Mensaje</button>
        </form>
    </div>

    <?php include 'includes/footer.php'; ?>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
