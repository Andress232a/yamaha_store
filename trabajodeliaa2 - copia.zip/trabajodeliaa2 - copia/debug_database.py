from app.models.models import db, Moto
from app import create_app

def debug_database():
    app = create_app()
    with app.app_context():
        # Contar motos totales
        total_motos = Moto.query.count()
        print(f"Total de motos en la base de datos: {total_motos}")
        
        # Contar motos por categoría
        categorias = db.session.query(Moto.categoria.distinct()).all()
        print("\nMotos por categoría:")
        for categoria in categorias:
            categoria = categoria[0]
            motos_categoria = Moto.query.filter(Moto.categoria == categoria).all()
            print(f"{categoria}: {len(motos_categoria)} motos")
            for moto in motos_categoria:
                print(f"  - {moto.modelo}")

if __name__ == '__main__':
    debug_database()
