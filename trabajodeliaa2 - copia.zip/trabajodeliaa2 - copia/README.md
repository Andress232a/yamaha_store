# Yamaha Motorcycle Sales Website

## Descripción
Sitio web profesional para la venta de motocicletas Yamaha, desarrollado con Python, Flask y SQLAlchemy.

## Requisitos
- Python 3.8+
- pip (gestor de paquetes)
- Navegador web moderno

## Instalación
1. Clonar el repositorio
2. Crear un entorno virtual: `python -m venv venv`
3. Activar entorno virtual
4. Instalar dependencias: `pip install -r requirements.txt`
5. Inicializar base de datos: `flask db upgrade`
6. Ejecutar la aplicación: `flask run`

## Características
- Catálogo de motos Yamaha
- Detalles de cada modelo
- Formulario de contacto
- Diseño responsivo

## Tecnologías
- Frontend: HTML5, CSS3, Bootstrap
- Backend: Python, Flask
- Base de datos: SQLAlchemy (SQLite/PostgreSQL)
- ORM: SQLAlchemy
- Gestión de migraciones: Flask-Migrate
